export async function GET() {
  const backendBase = process.env.BACKEND_URL || "http://localhost:4443";
  const r = await fetch(`${backendBase}/api/store/navigation`, { cache: "no-store" });
  const body = await r.text();

  return new Response(body, {
    status: r.status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
    },
  });
}
